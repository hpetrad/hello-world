package com.example.android.myquizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int countryScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void evaluate(View view) {

        EditText inputText = findViewById(R.id.name_field);
        CheckBox heroSquare = findViewById(R.id.herosquerae);
        CheckBox hagymatikum = findViewById(R.id.hagymatikum);
        CheckBox citadellaBox = findViewById(R.id.citadella);
        RadioButton first = findViewById(R.id.firstBudapest);
        RadioButton nineMillion = findViewById(R.id.ninemillion);
        RadioButton chcake = findViewById(R.id.chcake);
        RadioButton goulash = findViewById(R.id.goulash);
        RadioButton culture = findViewById(R.id.culture);

        if (first.isChecked()) {
            countryScore++;
        }

        if (nineMillion.isChecked()) {
            countryScore++;
        }

        if (chcake.isChecked()) {
            countryScore++;
        }

        if (goulash.isChecked()) {
            countryScore++;
        }

        if (culture.isChecked()) {
            countryScore++;
        }

        if (heroSquare.isChecked()) {
            countryScore++;
        }

        if (hagymatikum.isChecked()) {
            countryScore++;
        }

        if (citadellaBox.isChecked()) {
            countryScore++;
        }

        String typedText = inputText.getText().toString();

        if (typedText.matches("")) {
            Toast toast = Toast.makeText(this, typedText + "Please fill out the Your Name field.", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            return;
        } else {

            if (countryScore == 0) {
                Toast toast = Toast.makeText(this, typedText + ", You do not know much about Hugary.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                countryScore = 0;
                return;
            }

            if (countryScore <= 3) {
                Toast toast = Toast.makeText(this, typedText + ", You know quite much about Hungary.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                countryScore = 0;
                return;
            }

            if (countryScore == 6) {
                Toast toast = Toast.makeText(this, typedText + ", You are familiar with Hungary.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                countryScore = 0;
                return;
            }
        }

    }
}