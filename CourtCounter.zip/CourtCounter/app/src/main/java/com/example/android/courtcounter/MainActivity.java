package com.example.android.courtcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    /**
     * Score Team A
     */
    int scoreTeamA = 0;
    /**
     * Score Team B
     */
    int scoreTeamB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForTeamA(8);
    }
    /**
     * Reset button settings
     */
    public void resetScore(View v) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);
    }
    /**
     * Displays the given score for Team Petra.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }
    public void addFifteenForTeamA(View v){
        scoreTeamA = scoreTeamA + 15;
        displayForTeamA (scoreTeamA);
    }
    public void addThirtyForTeamA(View v){
        scoreTeamA = scoreTeamA + 30;
        displayForTeamA (scoreTeamA);
    }
    public void addFourtyForTeamA(View v){
        scoreTeamA = scoreTeamA + 40;
        displayForTeamA (scoreTeamA);
    }
    public void addOneForTeamA(View v){
        scoreTeamA = scoreTeamA + 1;
        displayForTeamA (scoreTeamA);
    }
    /**
     * Displays the given score for Team Viktor.
     */
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForTeamB(View v) {
        scoreTeamB = scoreTeamB + 1;
        displayForTeamB(scoreTeamB);
    }
    public void addFifteenForTeamB(View v) {
        scoreTeamB = scoreTeamB + 15;
        displayForTeamB(scoreTeamB);
    }
    public void addThirtyForTeamB(View v) {
        scoreTeamB = scoreTeamB + 30;
        displayForTeamB(scoreTeamB);
    }
    public void addFourtyForTeamB(View v) {
        scoreTeamB = scoreTeamB + 40;
        displayForTeamB(scoreTeamB);
    }
}
